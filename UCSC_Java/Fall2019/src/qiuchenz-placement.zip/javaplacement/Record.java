// Name: Qiuchen Zhang
// Andrew-ID: qiuchenz
package javaplacement;

public class Record{
	public String productCode;
	public String nutrientCode;
	public String nutrientName;
	public Record(String productCode, String nutrientCode, String nutrientName){
		this.productCode = productCode;
		this.nutrientCode = nutrientCode;
		this.nutrientName = nutrientName;
	}
	
	
}
