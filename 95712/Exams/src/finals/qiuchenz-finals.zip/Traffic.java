// Name: Qiuchen Zhang
// AndrewID: qiuchenz

package finals;

import java.util.Random;

public class Traffic implements Runnable {
	final static int MIN_VEHICLE_DELAY = 10;
	final static int MAX_VEHICLE_DELAY = 100;
	static int maxQLength;
	static int exit_count; // number of exited impatientVehicles
	
	@Override
	public void run() {
		int delay;
		while(Vehicle.vehicleCount < Road.maxVehicles) {
			Random randDelay = new Random();
			Random randomVehicle = new Random();
			delay = randDelay.nextInt(MAX_VEHICLE_DELAY - MIN_VEHICLE_DELAY + 1) + 10; // genereate delay
			
			Vehicle vechile;
			

			// lock the vehicleQ
			synchronized (Road.vehicleQ) {
				// 1/4 vehicles are impatient
				if (Road.problemPart == 2) {
					if (randomVehicle.nextInt(4) == 0)
						vechile = new ImpatientVehicle();
					else
						vechile = new Vehicle();
				}
				else {
					vechile = new Vehicle();
				}
				
				// impatientVehicle exits
				if (!vechile.joinVehicleQ()) {
					String light = TrafficLight.isGreen ? "Green" : "RED"; 
					System.out.printf("********* %s: %s %d exiting. Q length %d\n", light, vechile.getClass().getSimpleName(), vechile.id, Road.vehicleQ.size());
					exit_count++;
					continue;
				}
				
				// update maxQLength
				maxQLength = Math.max(maxQLength, Road.vehicleQ.size());
				
				// vehicle waits in vehicleQ
				if (!TrafficLight.isGreen) {
					System.out.printf("\tRED: %s %d in Q. Q length %d\n", vechile.getClass().getSimpleName(), vechile.id, Road.vehicleQ.size());
				}
			}
			
			// immediately exit if all vehicles arrived
			// don't wait for next vehicle
			if (Vehicle.vehicleCount >= Road.maxVehicles)
				break;
			
			// wait for next vehicle
			try {
				Thread.sleep(delay);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	
}
