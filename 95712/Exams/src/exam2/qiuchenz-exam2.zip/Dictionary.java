package exam2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Dictionary extends WordReference{
	public Dictionary(String filename) {
		// TODO Auto-generated constructor stub
		StringBuilder content = new StringBuilder();
		try {
			Scanner input = new Scanner(new File(filename));
			while(input.hasNextLine()) {
				content.append(input.nextLine() + "\n");
			}
			input.close();
			String [] contentArray = content.toString().split("\n");
			wordData = new String [contentArray.length][2];
			for (int i = 0; i < wordData.length; i++) {
				String line = contentArray[i];
				wordData[i][0] = line.split("[(]")[0].trim().toLowerCase();
				wordData[i][1] = line.split("[)]")[1].trim();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	@Override
	String[] lookup(String word) {
		// TODO Auto-generated method stub
		String output = "";
		for (String[] check : wordData) {
			if(check[0].trim().equalsIgnoreCase(word.trim())) {
				output += check[1] + "\n";
			}
		}
		if(output.length() == 0)
			return null;
		else {
			return output.split("\n");
		} 
	}

}
