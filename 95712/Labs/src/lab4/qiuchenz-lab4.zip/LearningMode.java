// Name: Qiuchen Zhang
// AndrewID: qiuchenz
package lab4;

public interface LearningMode {
	void learn(Content content);
}
