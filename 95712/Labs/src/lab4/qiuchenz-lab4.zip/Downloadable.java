// Name: Qiuchen Zhang
// AndrewID: qiuchenz
package lab4;

public interface Downloadable {
	void download();
}
